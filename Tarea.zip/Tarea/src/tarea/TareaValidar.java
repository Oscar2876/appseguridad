import java.io.*;
import java.util.Scanner;

public class TareaValidar {

    public static void main(String[] args) {

        // Solicitamos el nombre y la clave de usuario por teclado
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese su nombre de usuario: ");
        String nombreUsuario = scanner.nextLine();

        System.out.print("Ingrese su contraseña: ");
        String claveUsuario = scanner.nextLine();

        // Cargamos la ruta del archivo donde tenemos almacenado los datos
        String archivoUsuarios = "C:\\Users\\noel-\\Desktop\\Oscar\\Complexivo\\recordatorio Programcion Visual\\Tarea\\src\\tarea\\usuarios.txt";

        // Con esta linea podemos realizar la validacion si el usuario exista o no dentro de la lista
        boolean usuarioValido = false;

        try {
            // Con esta linea podemos abrir el archivo
            BufferedReader reader = new BufferedReader(new FileReader(archivoUsuarios));
            String linea;

            // Leer el archivo línea por línea
            while ((linea = reader.readLine()) != null) {
                // En este fragmento dividimos con ":" el usuario y la clave y con .trim() eliminamos los espacios que 
                //existan al incio o al final
                String[] partes = linea.split(":");

                if (partes.length == 2) {
                    String usuario = partes[0].trim();
                    String clave = partes[1].trim();

                    // Verificamos que coincidan los valores ingresados con los valores del archivo
                    if (usuario.equals(nombreUsuario) && clave.equals(claveUsuario)) {
                        usuarioValido = true;
                        break;
                    }
                }
            }

            // En esta linea cerramos el archivo 
            reader.close();

            // Aqui mostramos la respuesta si se encontro el usuario dentro del archivo txt
            if (usuarioValido) {
                System.out.println("¡Inicio de sesión exitoso!");
            } else {
                System.out.println("Nombre de usuario o contraseña incorrectos.");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
