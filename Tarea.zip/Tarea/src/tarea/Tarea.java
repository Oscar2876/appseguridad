package tarea;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Tarea {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el nombre a buscar: ");
        String usuariob = scanner.nextLine();

        // Configuración de la conexión a la base de datos
        String url = "jdbc:postgresql://localhost:5433/prueba";
        String usuario = "postgres";
        String contrasena = "admin";

        // Enviamos la consulta, en este caso que le busque por nombre
        String consultaSQL = "SELECT * FROM usuarios WHERE nombre = ?";

        try (
                Connection conexion = DriverManager.getConnection(url, usuario, contrasena);
                PreparedStatement ps = conexion.prepareStatement(consultaSQL);) {
  
            //Con esta linea evitamos un injectionsql ya que no permitimos el ingreso de consultas como :
            //' OR '1'='1
            ps.setString(1, usuariob);
            

            // Ejecutamos la consulta
            ResultSet rs = ps.executeQuery();

            boolean hayResultados = false;
            // Busca el nombre dentro de la tabla con un while hasta encontrarlo
            while (rs.next()) {
                hayResultados = true;
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                String correo = rs.getString("correo");
                System.out.println("ID: " + id + ", Nombre: " + nombre + ", Correo: " + correo);
            }
            if (!hayResultados) {
                System.out.println("No se encontraron resultados.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

}
